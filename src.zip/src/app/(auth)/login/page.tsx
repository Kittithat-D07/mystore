"use client";
import { signIn } from "next-auth/react";
import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { preAuthCheck } from "../../actions/auth";
import { Eye, EyeOff, ArrowRight, Lock, Mail } from "lucide-react";

const S = {
  page: { minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", padding:"24px", background:"var(--bg)" },
  card: { width:"100%", maxWidth:"420px", background:"var(--bg-card)", border:"1.5px solid var(--border)", borderRadius:"24px", padding:"40px", boxShadow:"0 8px 40px rgba(109,40,217,0.10)" },
  logo: { width:48, height:48, background:"var(--accent)", borderRadius:"14px", display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 20px", fontSize:"22px" },
  h1: { textAlign:"center" as const, fontSize:"26px", fontWeight:800, color:"var(--ink)", marginBottom:"6px" },
  sub: { textAlign:"center" as const, fontSize:"14px", color:"var(--ink-3)", marginBottom:"28px" },
  err: { background:"#FEE2E2", border:"1px solid #FECACA", color:"#991B1B", padding:"12px 16px", borderRadius:"12px", fontSize:"13px", fontWeight:600, marginBottom:"18px" },
  label: { display:"block", fontSize:"11px", fontWeight:700, textTransform:"uppercase" as const, letterSpacing:"0.1em", color:"var(--ink-3)", marginBottom:"6px" },
  inputWrap: { position:"relative" as const },
  input: { width:"100%", padding:"12px 44px 12px 44px", background:"var(--bg-soft)", border:"1.5px solid var(--border)", borderRadius:"12px", fontSize:"14px", fontWeight:500, color:"var(--ink)", boxSizing:"border-box" as const },
  icon: { position:"absolute" as const, left:14, top:"50%", transform:"translateY(-50%)", color:"var(--ink-3)", pointerEvents:"none" as const },
  eyeBtn: { position:"absolute" as const, right:12, top:"50%", transform:"translateY(-50%)", background:"none", border:"none", cursor:"pointer", color:"var(--ink-3)", padding:4 },
  row: { display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"6px" },
  forgotLink: { fontSize:"12px", color:"var(--ink-3)", textDecoration:"none", fontWeight:600 },
  submitBtn: { width:"100%", padding:"13px", background:"var(--accent)", color:"#fff", border:"none", borderRadius:"12px", fontSize:"15px", fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:8, marginTop:"6px" },
  divider: { display:"flex", alignItems:"center", gap:12, margin:"20px 0", color:"var(--ink-3)", fontSize:"12px" },
  divLine: { flex:1, height:1, background:"var(--border)" },
  footerText: { textAlign:"center" as const, fontSize:"13px", color:"var(--ink-3)", marginTop:"20px" },
  link: { color:"var(--accent)", fontWeight:700, textDecoration:"none" },
};

function LoginContent() {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw]     = useState(false);
  const [error, setError]       = useState("");
  const [loading, setLoading]   = useState(false);
  const router      = useRouter();
  const searchParams = useSearchParams();
  const callbackUrl = searchParams.get("callbackUrl") || "/";

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError("");
    const check = await preAuthCheck(email, password);
    if (check.error) { setError(check.error); setLoading(false); return; }
    const res = await signIn("credentials", { email, password, redirect: false });
    if (res?.error) setError("อีเมลหรือรหัสผ่านไม่ถูกต้อง");
    else { router.push(callbackUrl); router.refresh(); }
    setLoading(false);
  };

  return (
    <div style={S.page}>
      <div style={S.card}>
        <div style={S.logo}>🛍️</div>
        <h1 style={S.h1}>ยินดีต้อนรับกลับ</h1>
        <p style={S.sub}>เข้าสู่ระบบเพื่อดำเนินการต่อ</p>

        {error && <div style={S.err}>⚠️ {error}</div>}

        <form onSubmit={handleLogin} style={{ display:"flex", flexDirection:"column", gap:16 }}>
          <div>
            <label style={S.label}>อีเมล</label>
            <div style={S.inputWrap}>
              <Mail size={16} style={S.icon} />
              <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="your@email.com" required style={S.input} />
            </div>
          </div>
          <div>
            <div style={S.row}>
              <label style={{...S.label, marginBottom:0}}>รหัสผ่าน</label>
              <Link href="/forgot-password" style={S.forgotLink}>ลืมรหัสผ่าน?</Link>
            </div>
            <div style={S.inputWrap}>
              <Lock size={16} style={S.icon} />
              <input type={showPw?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••" required style={S.input} />
              <button type="button" style={S.eyeBtn} onClick={()=>setShowPw(!showPw)}>
                {showPw ? <EyeOff size={18}/> : <Eye size={18}/>}
              </button>
            </div>
          </div>
          <button type="submit" disabled={loading} style={{...S.submitBtn, opacity:loading?0.7:1}}>
            {loading ? "กำลังตรวจสอบ..." : <><span>เข้าสู่ระบบ</span><ArrowRight size={17}/></>}
          </button>
        </form>

        <div style={S.divider}><div style={S.divLine}/><span>หรือ</span><div style={S.divLine}/></div>
        <p style={S.footerText}>ยังไม่มีบัญชี? <Link href="/register" style={S.link}>สมัครสมาชิก</Link></p>
        <p style={{...S.footerText, marginTop:10}}><Link href="/" style={{...S.link, color:"var(--ink-3)"}}>← กลับหน้าร้านค้า</Link></p>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"var(--bg)"}}><div style={{width:32,height:32,border:"3px solid var(--border)",borderTopColor:"var(--accent)",borderRadius:"50%",animation:"spin 0.8s linear infinite"}} /></div>}>
      <LoginContent />
    </Suspense>
  );
}
